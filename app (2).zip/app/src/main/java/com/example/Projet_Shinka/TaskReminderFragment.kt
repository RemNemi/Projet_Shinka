package com.example.Projet_Shinka

import androidx.fragment.app.Fragment

class TaskReminderFragment : Fragment() {
    // Implémentations ici...
}
